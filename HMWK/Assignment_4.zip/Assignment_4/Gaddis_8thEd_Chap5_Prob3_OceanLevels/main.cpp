/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Created on July 8, 2016, 11:03 PM
 * Purpose: Ocean Levels
 */

//System Libraries

#include <iostream> //Input/Output Library
#include <iomanip>
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {

    //Declare Variables
    int years=25;
    float ocLvl=0;    //ocean level is rising at about 1.5 mm per year 
    
    
    //Input Data
    
   
    
    //Process the Data and output simultaneously
    for (int i=1;i<=years; i++)
    {
        ocLvl+=1.5;
        cout<<"year"<<i<<": "<<ocLvl<<"mm\n"<<endl;
                
    }
      
    
    //Exit Stage Right!
     return 0;
}

