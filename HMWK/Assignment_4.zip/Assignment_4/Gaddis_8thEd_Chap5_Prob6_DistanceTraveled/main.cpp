/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Created on July 8, 2016, 11:35 AM
 * Purpose: Distance Traveled
 */

//System Libraries

#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {

    //Declare Variables
    float distance;
    float speed;
    int time;
    //Input Data
    cout<<"What is the speed of the vehicle? ";
    cin>>speed;
    cout<<"How many hours did it travel? ";
    cin>> time;
    
    //Process the Data and output simultaneously
    cout<<"\nHour\tDistance Traveled\n";
    cout<<"------------------------\n";
    
    for (int i=1;i<=time;i++)
    {
        distance=speed*i;
        cout<<i<<"\t\t"<<distance<<endl;
    }
    
    //Exit Stage Right!
     return 0;
}

