/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Created on July 11, 2016, 7:03 PM
 * Purpose: Sum of Numbers
 */

//System Libraries

#include <iostream> //Input/Output Library
#include <iomanip>
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {

    //Declare Variables
    char letters;
    
    //Input Data
    cout<<"Below will display the characters for the ASCII codes 0 through ";
    cout<<"127"<<endl;
   
    
    //Process the Data and output simultaneously
    for (int i=0;i<=127; ++i)
    {
        for(int j=1;j<=16;j++,i++)
        {
            cout<<(char)i;
    }
        cout<<endl;
    }
           
    
    //Exit Stage Right!
     return 0;
}

