/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Created on July 9, 2016, 10:35 AM
 * Purpose: The Greatest and Least of These
 */

//System Libraries

#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {

    //Declare Variables
    int number=0;
    int high, low, counter=0;
    
    //Input Data
    
    //Process the Data and output simultaneously  
    while (number != -99)
    {
        cout<<"Please enter whole numbers. Enter -99 to end the series";
        cin>>number;
        
        if (counter == 0)
        {
            high=number;
            low=number;
        }
        else
        {
            if(number>high && number!=-99)
                high=number;
            else if (number<low && number!=-99)
                low=number;
        }
        counter++;
    }
    cout<<"The highest number you entered was "<<high<<endl;
    cout<<"the smaller number you entered was "<<low<<endl;
    //Exit Stage Right!
     return 0;
}

