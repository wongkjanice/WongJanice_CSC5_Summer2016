/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Created on July 8, 2016, 10:03 AM
 * Purpose: Calories Burned
 */

//System Libraries

#include <iostream> //Input/Output Library
#include <iomanip>
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {

    //Declare Variables
    float cal;          //Total calories burned
    float calpMin=3.6f;   //
    
    //Input Data
 
    //Process the Data and output simultaneously
    for (int i=10;i<=30; i+=5)
    {
        cal=i*calpMin;
        cout<<"In "<<i<<" minutes you burned "<<cal<<"calories.\n"<<endl;          
    }
      
    
    //Exit Stage Right!
     return 0;
}

