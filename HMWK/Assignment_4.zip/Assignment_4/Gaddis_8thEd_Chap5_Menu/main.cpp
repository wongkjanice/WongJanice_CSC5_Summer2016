/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Created on July 10, 2016, 7:03 PM
 * Purpose: Menu for Chapter 5 Gaddis
 */

//System Libraries

#include <iostream> //Input/Output Library
#include <iomanip>
#include <cmath>
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    int choice;
    do
    {
        //Menu Options
        cout<<"Type 1 for Sum of Numbers"<<endl;
        cout<<"Type 2 for ASCII"<<endl;
        cout<<"Type 3 for Ocean Levels"<<endl;
        cout<<"Type 4 for Calories Burned"<<endl;
        cout<<"Type 5 for Membership Fees"<<endl;
        cout<<"Type 6 for Distance Traveled"<<endl;
        cout<<"Type 7 for Show Me The Money"<<endl;
        cout<<"Type 8 for Greatest and Least of These"<<endl;
        cout<<"Type 9 for 99 Bottles of Beer"<<endl;
        cout<<"Type 10 to quit menu"<<endl;
        cin>>choice;
        
        if(choice==1)
            {
            //Declare Variables
            int pNum; //Positive Number

            //Input Data
             cout<<"Enter a positive integer: ";
             cin>>pNum;

            //Process the Data and Output the Data
             int sum=0;
             for(int num=0; num<pNum; num++)
             {
                 sum+=num;
                 cout<<"The sum total of all the integers is "<<sum<<endl;
             }
        }
        else if(choice==2)
            {
            //Declare Variables
            char letters;

            //Input Data
            cout<<"Below will display the characters for the ASCII codes 0 through ";
            cout<<"127"<<endl;

            //Process the Data and output simultaneously
            for (int i=0;i<=127; ++i)
            {
                for(int j=1;j<=16;j++,i++)
                {
                    cout<<(char)i;
            }
                cout<<endl;
            }

        }
        else if(choice==3)
        {
            //Declare Variables
            int years=25;
            float ocLvl=0;    //ocean level is rising at about 1.5 mm per year 

            //Process the Data and output simultaneously
            for (int i=1;i<=years; i++)
            {
                ocLvl+=1.5;
                cout<<"year"<<i<<": "<<ocLvl<<"mm\n"<<endl;

            }

                }
        else if(choice==4)
        {
            //Declare Variables
            float cal;          //Total calories burned
            float calpMin=3.6f;   //calories per minute 

            //Process the Data and output simultaneously
            for (int i=10;i<=30; i+=5)
            {
                cal=i*calpMin;
                cout<<"In "<<i<<" minutes you burned "<<cal<<"calories.\n"<<endl;          
            }


                }
        else if(choice==5)
        {
            //Declare Variables
            const float INCREASE=0.04;   //Membership fee percentage increase
            const int YEARS=6;
            float member=2500;           //Membership fee per year

            //Input Data

            //Process the Data and output simultaneously
            for (int i=1;i<=YEARS; i++)
            {
                member=member+(member*INCREASE);
                cout<<"Year "<<i<<" fees are: $"<<member<<endl;        
            }

                }
        else if(choice==6)
        {
            //Declare Variables
                float distance;
                float speed;
                int time;
                //Input Data
                cout<<"What is the speed of the vehicle? ";
                cin>>speed;
                cout<<"How many hours did it travel? ";
                cin>> time;

                //Process the Data and output simultaneously
                cout<<"\nHour\tDistance Traveled\n";
                cout<<"------------------------\n";

                for (int i=1;i<=time;i++)
                {
                    distance=speed*i;
                    cout<<i<<"\t\t"<<distance<<endl;
                }

                    }
        else if(choice==7)
        {
                //Declare Variables
                float pennies=1;  //Initial pay per day 
                float payDay=0;   //Pay at the end of the month

                //Process the Data and output simultaneously
                for(int day=1;day<=30;day++){
                    payDay=payDay+pennies;
                    cout<<fixed<<setprecision(2)<<showpoint;
                    cout<<"Day "<<setw(2)<<day<<" Pay rate = $"<<setw(10)<<pennies/100;
                    cout<<" Pay earned $"<<setw(11)<<payDay/100<<endl;
                    pennies=pennies*2;

                }            
        }
        else if(choice==8)
        {
            //Declare Variables
            int number=0;
            int high, low, counter=0;

            //Input Data

            //Process the Data and output simultaneously  
            while (number != -99)
            {
                cout<<"Please enter whole numbers. Enter -99 to end the series";
                cin>>number;

                if (counter == 0)
                {
                    high=number;
                    low=number;
                }
                else
                {
                    if(number>high && number!=-99)
                        high=number;
                    else if (number<low && number!=-99)
                        low=number;
                }
                counter++;
            }
            cout<<"The highest number you entered was "<<high<<endl;
            cout<<"the smaller number you entered was "<<low<<endl;            
                }
        else if(choice==9)
        {
            int times;
            //Process the Data and Output
            for(int bottles=99;bottles>=1;bottles--){
                //Calculate tens and ones
                int nTens=(bottles-bottles%10)/10;  //Number of 10's 
                int nOnes=bottles-nTens*10;         //Number of 1's
                for(int times=1;times<=3;times++){
                    if(times==3){
                        int temp=bottles-1;
                        nTens=(temp-temp%10)/10;
                        nOnes=temp-nTens*10;
                    }
                }
                switch(nTens){
                    case 9:cout<<"Ninety ";break;
                    case 8:cout<<"Eighty ";break;
                    case 7:cout<<"Seventy ";break;
                    case 6:cout<<"Sixty ";break;
                    case 5:cout<<"Fifty ";break;
                    case 4:cout<<"Fourty ";break;
                    case 3:cout<<"Thirty ";break;
                    case 2:cout<<"Twenty ";break;
                    case 1:{
                        switch(nOnes){
                            case 1:cout<<"Eleven ";break;
                            case 2:cout<<"Twelve ";break;
                            case 3:cout<<"Thirteen ";break;
                            case 4:cout<<"Fourteen ";break;
                            case 5:cout<<"Fifteen ";break;
                            case 6:cout<<"Sixteen ";break;
                            case 7:cout<<"Seventeen ";break;
                            case 8:cout<<"Eighteen ";break;
                            case 9:cout<<"Nineteen ";break;     
                        }   
                    }
                }
                if(nTens!=1){
                        switch(nOnes){
                            case 0:cout<<"Zero ";break;
                            case 1:cout<<"One ";break;
                            case 2:cout<<"Two ";break;
                            case 3:cout<<"Three ";break;
                            case 4:cout<<"Four ";break;
                            case 5:cout<<"Five ";break;
                            case 6:cout<<"Six ";break;
                            case 7:cout<<"Seven ";break;
                            case 8:cout<<"Eight ";break; 
                            case 9:cout<<"Nine ";break; 
                        }
                    }    
                    if(times==1||times==3)cout<<"bottles of beer on the wall"<<endl;
                    else if(times==2){
                        cout<<" bottles of beer"<<endl;  
                        cout<<" You can take one down and pass it around "<<endl;


                    }         
                }

            cout<<endl;            
                }     
    }
        while(choice!=10); //do while 
             return 0;

}

