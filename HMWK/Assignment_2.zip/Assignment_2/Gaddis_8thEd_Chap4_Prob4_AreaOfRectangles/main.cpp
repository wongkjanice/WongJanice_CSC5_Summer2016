/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Janice Wong
 * Created on July 1, 2016, 4:44 PM
 * Purpose: Areas of Rectangles 
 */

//System Libraries

#include <iostream> //Input/Output Library

using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    float length1, length2, width1, width2;
    float area1, area2;
    
    //Input Data
    cout<<"Enter length and width of the first rectangle: ";
    cin>>length1>>width1;
    
    cout<<"Enter length and width of the second rectangle: ";
    cin>>length2>>width2;
    
    //Process the Data
    area1=length1*width1;
    area2=length2*width2;
    
	
    //Output the processed Data
    if (area1>area2)
        cout<<"The first rectangle has the greater area."<<endl;
    else if (area1<area2)
        cout<<"The second rectangle has the greater area. "<<endl;
    else if (area1==area2)
        cout<<"The two rectangles have the same area. "<<endl;
       
    
    //Exit Stage Right!
     return 0;
}