/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Janice Wong
 * Created on July 1, 2016, 3:54 PM
 * Purpose: Magic Date
 */

//System Libraries

#include <iostream> //Input/Output Library

using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    int month, day, year;
    
    //Input Data
    cout<<"Enter a month(in numeric form), a day, and a two-digit year: ";
    cin>>month>>day>>year;
    
    //Process the Data
    
	
    //Output the processed Data
    if (month*day==year)
        cout<<"The date is magic."<<endl;
    else 
        cout<<"The date is not magic."<<endl;
    
    
    //Exit Stage Right!
     return 0;
}