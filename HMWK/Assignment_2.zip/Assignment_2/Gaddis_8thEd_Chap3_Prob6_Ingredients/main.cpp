/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Created on June 29, 2016, 12:36 AM
 * Purpose: Ingredient Adjuster
 */

//System Libraries

#include <iostream> //Input/Output Library
#include <iomanip>  //Formatting Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    int nCook;
    float sugar, butter, flour;
    float cSugar, cButter, cFlour;

    //Input Data
    sugar=0.03125f;
    butter=0.02083f;
    flour=0.05729f;
    
    
    //Process the Data
    cout<<"How many cookies would you like to make? ";
    cin>>nCook;
    
    cSugar=nCook*sugar;
    cButter=nCook*butter;
    cFlour=nCook*flour;
    
	
    //Output the processed Data
    cout<<setprecision(3)<<showpoint;
    cout<<"You will need ";
    cout<<cSugar<<" cups of sugar, "<<cButter<<" cups of butter, "<<cFlour<<" cups of flour";
    cout<<"to make "<<nCook<<" cookies."<<endl;
         
    
    
    //Exit Stage Right!
     return 0;
}

