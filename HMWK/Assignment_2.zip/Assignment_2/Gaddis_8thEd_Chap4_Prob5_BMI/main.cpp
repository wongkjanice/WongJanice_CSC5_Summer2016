/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Janice Wong
 * Created on July 1, 2016, 5:20 PM
 * Purpose: Body Mass Index
 */

//System Libraries

#include <iostream> //Input/Output Library

using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    float BMI, weight, height;
    
    //Input Data
    cout<<"Enter your weight in pounds: ";
    cin>>weight;
    
    cout<<"Enter your height in inches: ";
    cin>>height;
    
    //Process the Data
    BMI=weight*(703/(height*height));
    
	
    //Output the processed Data
    if (BMI<18.5)
        cout<<"You are underweight."<<endl;
    else if (BMI>=18.5 && BMI<=25)
        cout<<"You are at optimal weight."<<endl;
    else if (BMI>25)
        cout<<"You are overweight. "<<endl;
       
    
    //Exit Stage Right!
     return 0;
}