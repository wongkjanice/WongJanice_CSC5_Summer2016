/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Janice Wong
 * Created on July 3, 2016, 2:20 PM
 * Purpose: Menu for Gaddis Chapter 4
 */

//System Libraries
#include <iostream>     //Input/Output Library
#include <iomanip>      //Formatting Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    char choice;
    
    //Input Data
    cout<<"Menu Program"<<endl;
    cout<<"Choose which program problem you would like to view: "<<endl;
    cout<<"Type 1 for Min/Max"<<endl;
    cout<<"Type 2 for Roman Numerals"<<endl;
    cout<<"Type 3 for Magic Date"<<endl;
    cout<<"Type 4 for Area of Rectangles"<<endl;
    cout<<"Type 5 for BMI"<<endl;
    cout<<"Type 6 for Mass and Weight"<<endl;
    cout<<"Type 7 for Roman Conversion"<<endl;
    cout<<"Type 8 for Black Jack Hand Value"<<endl;
    cout<<"Type 9 for Ribonacci Crud"<<endl;
    cin>>choice;
    
    //Process the Data
    switch(choice){
        case '1':{
                //Declare Variables
                float n1,n2; //Numbers

                //Input Data
                cout<<"Enter two numbers: ";
                cin>>n1>>n2;

                //Output the processed Data
                if (n1>n2)
                    cout<<"The larger number is: "<<n1<<endl;
                else 
                    cout<<"The larger number is: "<<n2<<endl;

                //Exit the switch
                break;
        }
        case '2':{
                //Declare Variables
                int romNum=0;

                //Input Data
                cout<<"Enter a number (1-10): ";
                cin>>romNum;

                //Output the processed Data
                if (romNum>0 && romNum<=10)
                {
                    cout<<"The Roman Numeral version of "<<romNum<<" is ";
                    switch(romNum)
                    {
                        case 1: cout<<"I"; break;
                        case 2: cout<<"II"; break;
                        case 3: cout<<"III"; break;
                        case 4: cout<<"IV"; break;
                        case 5: cout<<"V"; break;
                        case 6: cout<<"VI"; break;
                        case 7: cout<<"VII"; break;
                        case 8: cout<<"VIII"; break;
                        case 9: cout<<"IX"; break;
                        case 10: cout<<"X"; break;

                    }
                }
                //Exit the switch
                break;
                }
        case '3':{
               //Declare Variables
               int month, day, year;

               //Input Data
               cout<<"Enter a month(in numeric form), a day, and a two-digit year: ";
               cin>>month>>day>>year;

               //Output the processed Data
               if (month*day==year)
                   cout<<"The date is magic."<<endl;
               else 
                   cout<<"The date is not magic."<<endl;


               //Exit the switch
               break;
                   }
        case '4':{
                //Declare Variables
                float length1, length2, width1, width2;
                float area1, area2;

                //Input Data
                cout<<"Enter length and width of the first rectangle: ";
                cin>>length1>>width1;

                cout<<"Enter length and width of the second rectangle: ";
                cin>>length2>>width2;

                //Process the Data
                area1=length1*width1;
                area2=length2*width2;


                //Output the processed Data
                if (area1>area2)
                    cout<<"The first rectangle has the greater area."<<endl;
                else if (area1<area2)
                    cout<<"The second rectangle has the greater area. "<<endl;
                else if (area1==area2)
                    cout<<"The two rectangles have the same area. "<<endl;


                //Exit the switch
                break;
                    }
        
        case '5':{
                //Declare Variables
                float BMI, weight, height;

                //Input Data
                cout<<"Enter your weight in pounds: ";
                cin>>weight;

                cout<<"Enter your height in inches: ";
                cin>>height;

                //Process the Data
                BMI=weight*(703/(height*height));

                //Output the processed Data
                if (BMI<18.5)
                    cout<<"You are underweight."<<endl;
                else if (BMI>=18.5 && BMI<=25)
                    cout<<"You are at optimal weight."<<endl;
                else if (BMI>25)
                    cout<<"You are overweight. "<<endl;


                //Exit the switch
                break;
                    }
        case '6':{
                //Declare Variables
                float weight, mass;

                //Input Data
                cout<<"Enter the mass of the object: ";
                cin>>mass;

                //Process the Data
                weight=mass*9.8;

                //Output the processed Data
                cout<<"The weight of the object is "<<weight<<" newtons."<<endl;

                if (weight>1000)
                    cout<<"The object is too heavy"<<endl;
                else if (weight<10)
                    cout<<"The object is too light"<<endl;

                //Exit the swtich
                break;
                    }
        case '7':{
                //Declare Variables
                unsigned short x;   //number to convert
                unsigned char n1000s,n100s,n10s,n1s;    //Strip off the digits

                //Input Data
                cout<<"Input a number from 1000 to 3000 to convert "<<endl;
                cout<<"to a Roman Numeral"<<endl;
                cin>>x;

                //Process the Data
                if (x<1000||x>3000) return 1;

                //Output the processed Data
                //Thousand Position
                n1000s=(x-x%1000)/1000;
                switch(n1000s){
                    case 3:cout<<"M";
                    case 2:cout<<"M";
                    case 1:cout<<"M";
                }


                //Hundreds Position
                x=x-n1000s*1000;
                n100s=(x-x%100)/100;
                  switch(n100s){
                    case 9:cout<<"CM";break;
                    case 8:cout<<"DCCC";break;
                    case 7:cout<<"DCC";break;
                    case 6:cout<<"DC";break;
                    case 5:cout<<"D";break;
                    case 4:cout<<"CD";break;
                    case 3:cout<<"C";
                    case 2:cout<<"C";
                    case 1:cout<<"C";
                }

                //Tens Position
                x=x-n100s*100;
                n10s=(x-x%10)/10;
                  switch(n10s){
                    case 9:cout<<"XC";break;
                    case 8:cout<<"LXXX";break;
                    case 7:cout<<"LXX";break;
                    case 6:cout<<"LX";break;
                    case 5:cout<<"L";break;
                    case 4:cout<<"XL";break;
                    case 3:cout<<"X";
                    case 2:cout<<"X";
                    case 1:cout<<"X";
                }

                //Tens Position
                x=x-n10s*10;
                n1s=(x-x%1)/1;
                  switch(n1s){
                    case 9:cout<<"IX";break;
                    case 8:cout<<"VIII";break;
                    case 7:cout<<"VII";break;
                    case 6:cout<<"VI";break;
                    case 5:cout<<"V";break;
                    case 4:cout<<"IV";break;
                    case 3:cout<<"I";
                    case 2:cout<<"I";
                    case 1:cout<<"I";
                }

                //Exit the switch
                  break;
                    }
        case '8':{
                //Declare Variables
                char card;
                int value=0 ,excess=0;

                //Input Data
                cout<<"Input a card A,T,J,Q,K,2-9"<<endl;
                cin>>card;

                //Evaluate the first card
                 switch(card){
                    case 'K':
                    case 'Q':
                    case 'J':
                    case 'T':value=value+10;break;
                    case '9':
                    case '8':
                    case '7':
                    case '6':
                    case '5':
                    case '4':
                    case '3':
                    case '2':value=value+(card-48);break;
                    case 'A':value=value+11;excess=10;

                 }

                //Output the value
                 cout<<"The value of the hand at this point = "<<value<<endl;

                 //Input Data for second card
                cout<<"Input a card A,T,J,Q,K,2-9"<<endl;
                cin>>card;

                //Evaluate the second card
                 switch(card){
                    case 'K':
                    case 'Q':
                    case 'J':
                    case 'T':value=value+10;break;
                    case '9':
                    case '8':
                    case '7':
                    case '6':
                    case '5':
                    case '4':
                    case '3':
                    case '2':value=value+(card-48);break;
                    case 'A':value=value+11;excess=10;

                 }
                 if(value>21)value=value-excess;

                //Output the value for the second card 
                 cout<<"The value of the hand at this point = "<<value<<endl;

                //Input Data for third card
                cout<<"Input a card A,T,J,Q,K,2-9"<<endl;
                cin>>card; 

                //Evaluate the third card
                 switch(card){
                    case 'K':
                    case 'Q':
                    case 'J':
                    case 'T':value=value+10;break;
                    case '9':
                    case '8':
                    case '7':
                    case '6':
                    case '5':
                    case '4':
                    case '3':
                    case '2':value=value+(card-48);break;
                    case 'A':value=value+11;excess=10;

                 }
                 if(value>21)value=value-excess;

                //Output the value for the third card 
                 cout<<"The value of the hand at this point = "<<value<<endl;

                //Exit the switch
                 break;
                    }
        case '9':{
                //Declare Variables
                float crudWt,curntWt;    //Crud weight in lbs
                int fi=1, fip1=1, fip2;     //Fibonacci sequence
                int days=0; //Number of Days

                //Input Data
                cout<<"How many lbs of crud do you have?"<<endl;
                cin>>crudWt;

                //Process the Data - Day 0 
                curntWt=crudWt*fi;
                cout<<" Fi Days Weight"<<endl;
                cout<<setw(4)<<fi<<setw(5)<<days<<setw(7)<<curntWt<<endl;

                //Process the Data - Day 5 
                curntWt=crudWt*fip1;
                days=days+5;
                cout<<setw(4)<<fi<<setw(5)<<days<<setw(7)<<curntWt<<endl;

                //Process the Data - Day 10
                fip2=fip1;
                fip1=fi;
                fi=fip1+fip2;
                curntWt=crudWt*fi;
                days=days+5;
                cout<<setw(4)<<fi<<setw(5)<<days<<setw(7)<<curntWt<<endl;

                //Process the Data - Day 15
                fip2=fip1;
                fip1=fi;
                fi=fip1+fip2;
                curntWt=crudWt*fi;
                days=days+5;
                cout<<setw(4)<<fi<<setw(5)<<days<<setw(7)<<curntWt<<endl;

                //Output the processed Data

                //Exit the switch
                break;
                    }
               
    //Exit Stage Right!
     return 0;
}
}