/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Created on June 29, 2016, 12:36 AM
 * Purpose: Male and Female Percentage
 */

//System Libraries

#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    float malePer;
    float femPer;   //Percentage of Female and Male
    int nMale, nFemale,total; //Number of male and female
    
    //Input Data
    
    //Process the Data
        cout<<"Please enter the number of Male students in a class followed by the number of Female students in a class.";
	cin>>nMale>>nFemale;
 
	total=nMale+nFemale;
	malePer=static_cast<float>(nMale)/total;
	femPer=static_cast<float>(nFemale)/total;
 
	
    //Output the processed Data
        cout<<"Percentage of Male students is "<<malePer*100<<"%."<<endl;
	cout<<"Percentage of Female students is "<<femPer*100<<"%."<<endl;
    
    //Exit Stage Right!
     return 0;
}
