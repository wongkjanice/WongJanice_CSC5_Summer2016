/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Janice Wong
 * Created on July 1, 2016, 3:24 PM
 * Purpose: Roman Numerals
 */

//System Libraries

#include <iostream> //Input/Output Library

using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    int romNum=0;
    
    
    //Input Data
    cout<<"Enter a number (1-10): ";
    cin>>romNum;
    
    //Process the Data
    
	
    //Output the processed Data
    if (romNum>0 && romNum<=10)
    {
        cout<<"The Roman Numeral version of "<<romNum<<" is ";
        switch(romNum)
        {
            case 1: cout<<"I"; break;
            case 2: cout<<"II"; break;
            case 3: cout<<"III"; break;
            case 4: cout<<"IV"; break;
            case 5: cout<<"V"; break;
            case 6: cout<<"VI"; break;
            case 7: cout<<"VII"; break;
            case 8: cout<<"VIII"; break;
            case 9: cout<<"IX"; break;
            case 10: cout<<"X"; break;
          
        }
    }
    
    //Exit Stage Right!
     return 0;
}