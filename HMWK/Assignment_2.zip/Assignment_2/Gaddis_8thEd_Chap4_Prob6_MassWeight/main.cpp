/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Janice Wong
 * Created on July 2, 2016, 12:20 PM
 * Purpose: Mass and Weight
 */

//System Libraries

#include <iostream> //Input/Output Library

using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    float weight, mass;
    
    //Input Data
    cout<<"Enter the mass of the object: ";
    cin>>mass;
    
    //Process the Data
    weight=mass*9.8;
    
    //Output the processed Data
    cout<<"The weight of the object is "<<weight<<" newtons."<<endl;
    
    if (weight>1000)
        cout<<"The object is too heavy"<<endl;
    else if (weight<10)
        cout<<"The object is too light"<<endl;
          
    //Exit Stage Right!
     return 0;
}