/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Created on June 26, 2016, 11:58 PM
 * Purpose: Stadium Seating
 */

//System Libraries

#include <iostream> //Input/Output Library
#include <iomanip>  //Formatting Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    float classA, classB, classC;    //Class of ticket prices
    int nclA, nclB, nclC;   //number of class tickets sold
    float income;    //income generated from ticket sales
    
    //Input Data
    classA=15.00;
    classB=12.00;
    classC=9.00;
    
    //Process the Data
    
    
    //Output the processed Data
    cout<<"How many tickets were sold for Class A seats?\n";
    cin>>nclA;
    cout<<"How many tickets were sold for Class B seats?\n";
    cin>>nclB;
    cout<<"How many tickets were sold for Class C seats?\n";
    cin>>nclC;
    
    income=(classA*nclA)+(classB*nclB)+(classC*nclC);
    cout<<setprecision(5)<<fixed;
    cout<<"The total amount of income generated from ticket sales is $";
    cout<<income<<endl;
    
    //Exit Stage Right!
     return 0;
}

