/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Janice Wong
 * Created on June 30, 2016, 5:24 PM
 * Purpose: How Many Widgets?
 */

//System Libraries

#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    float widget=12.5;    //Widget weights 12.5 pounds each
    float nPallet;          //Number of pallets
    float pWeight, tWeight; //Pallet weight and total weight w/ widgets
    
    //Input Data
    cout<<"Enter pallet weight: ";
    cin>>pWeight;
    
    cout<<"Enter total weight of pallet with widget: ";
    cin>>tWeight;
    
    //Process the Data
    nPallet=(tWeight-pWeight)/widget;
	
    //Output the processed Data
    cout<<"The number of widgets stacked on the pallet is "<<nPallet<<endl;
    
    //Exit Stage Right!
     return 0;
}