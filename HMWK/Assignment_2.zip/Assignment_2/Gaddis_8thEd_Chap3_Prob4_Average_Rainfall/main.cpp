/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Created on June 26, 2016, 11:58 PM
 * Purpose: Test Average
 */

//System Libraries

#include <iostream> //Input/Output Library
#include <iomanip>  //Formatting Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    char month1[8],month2[8],month3[8];   //Months
    float avgRain;      //Average amount of rainfall
    float rFall;        //Amount of rainfall
    float tRFall=0;       //Total rainfall 
    
    //Input Data
   
    //Process the Data
    cout<<"Enter three consecutive months: ";
    cin>>month1>>month2>>month3;
    
    cout<<"How much inches of rain fell in "<<month1<<"?"<<endl;
    cin>>rFall;
    tRFall=tRFall+rFall;
    
    cout<<"How much inches of rain fell in "<<month2<<"?"<<endl;
    cin>>rFall;
    tRFall=tRFall+rFall;
    
    cout<<"How much inches of rain fell in "<<month3<<"?"<<endl;
    cin>>rFall;
    tRFall=tRFall+rFall;
    
    avgRain=tRFall/3;
    //Output the processed Data
    
  
    cout<<"The average rainfall for "<<month1<<", "<<month2;
    cout<<", "<<month3<<" is "<<avgRain<<" inches."<<endl;
    
    //Exit Stage Right!
     return 0;
}

