/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Janice Wong
 * Created on July 1, 2016, 1:44 PM
 * Purpose: Minimum/Maximum
 */

//System Libraries

#include <iostream> //Input/Output Library

using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    float n1,n2; //Numbers
    
    //Input Data
    cout<<"Enter two numbers: ";
    cin>>n1>>n2;
    
    //Process the Data
    
	
    //Output the processed Data
    if (n1>n2)
        cout<<"The larger number is: "<<n1<<endl;
    else 
        cout<<"The larger number is: "<<n2<<endl;
    
    //Exit Stage Right!
     return 0;
}