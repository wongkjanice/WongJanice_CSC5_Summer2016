/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Created on June 26, 2016, 10:58 PM
 * Purpose: Miles Per Gallon
 */

//System Libraries

#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    int nGal;   //number of gallons a car can hold
    int nMile;  //number of miles it can be driven on a full tank
    int mpg;   //miles per gallon of gas 
    //Input Data

    
    //Process the Data
    
    //Output the processed Data
    cout<<"Enter the number of gallons of gas the car can hold.\n";
    cin>>nGal;
    cout<<"Enter the number of miles it can be driven on a full tank.\n";
    cin>>nMile;
    
    mpg=nMile/nGal;
    
    cout<<"The number of miles that may be driven per gallon of gas is "<<mpg<<endl;
    
    //Exit Stage Right!
     return 0;
}

