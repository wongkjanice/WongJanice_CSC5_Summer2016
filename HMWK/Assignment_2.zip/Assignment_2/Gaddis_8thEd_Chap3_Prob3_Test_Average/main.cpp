/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Created on June 26, 2016, 11:58 PM
 * Purpose: Test Average
 */

//System Libraries

#include <iostream> //Input/Output Library
#include <cmath>
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    int test1, test2, test3, test4, test5; //To hold the score
    float avg;  //To hold the average
    
    //Input Data
   
    
    //Process the Data
    
    
    //Output the processed Data
    cout<<"Enter the first test score: ";
    cin>>test1;
    cout<<"Enter the second test score: ";
    cin>>test2;
    cout<<"Enter the third test score: ";
    cin>>test3;
    cout<<"Enter the fourth test score: ";
    cin>>test4;
    cout<<"Enter the fifth test score: ";
    cin>>test5;
    
    avg=(test1+test2+test3+test4+test5)/5.0;
    
    cout<<"The average score is: "<<avg<<endl;
    
    //Exit Stage Right!
     return 0;
}

