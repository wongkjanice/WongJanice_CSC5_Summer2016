/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Created on June 29, 2016, 5:36 PM
 * Purpose: Box Office
 */

//System Libraries

#include <iostream> //Input/Output Library
#include <iomanip>  //Formatting Library
#include <string>

using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    float adult, child, gross, net;
    float child_price = 6.00;
    float adult_price = 10.00;
    float cut;
    float cut_amt = ((float)20/100);
    string movieName;
    int noAdult;
    int noChild;

    
    //Input Data
    cout << "Enter name of movie" << endl;
    getline(cin, movieName);
    
    
    cout << "Enter how many adult tickets were sold" << endl;
    cin>>noAdult;
    cin.ignore();
    
    cout << "Enter how many child tickets were sold" << endl;
    cin>>noChild;
    
    //Process the Data
    adult = noAdult * adult_price;
    child = noChild * child_price;
    gross = adult + child;
    cut = gross * cut_amt;
    net = gross - cut;
  
    
   
    //Output the processed Data
    cout<<setprecision(6)<<showpoint;
    cout << "Movie Name:" <<setw(5)<<movieName<<endl;
    cout << "Adult Tickets Sold:" <<setw(5)<<noAdult<<endl;
    cout << "Child Tickets Sold:" <<setw(5)<<noChild<<endl;
    cout << "Gross Box Office Profit: $" <<setw(5)<<gross<<endl;
    cout<<setprecision(5)<<showpoint;
    cout << "Net Box Office Profit: $" <<setw(5)<<cut<<endl;
    cout<<setprecision(6)<<showpoint;
    cout << "Amount Paid to Distributor: $"<<setw(5)<<net<< endl;

    
    //Exit Stage Right!
     return 0;
}

