/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Janice Wong
 * Created on June 30, 2016, 5:44 PM
 * Purpose: How Many Calories
 */

//System Libraries

#include <iostream> //Input/Output Library
#include <iomanip>  //Formatting Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    int nCookie; //Number of cookies he/she ate, number of cookies in a bag
    float cookCal=33.3;    //Serving of cookies, serving of calories 
    float totCal;
    
    
    //Input Data
    cout<<"Enter number of cookies eaten: ";
    cin>>nCookie;
    
    //Process the Data
    totCal=nCookie*cookCal;
	
    //Output the processed Data
    cout<<setprecision(5)<<showpoint;
    cout<<"The total calories consumed were "<<totCal<<endl;
    
    //Exit Stage Right!
     return 0;
}