/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Purpose: Hello World
 * Created on June 21, 2016, 5:01 PM
 */

#include <iostream> //Input/Output Library

using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    
    //Input Data
    
    //Process the Data

    //Output the processed Data
    cout<<"Hello World!";
    
    //Exit Stage Right!
     return 0;
}

