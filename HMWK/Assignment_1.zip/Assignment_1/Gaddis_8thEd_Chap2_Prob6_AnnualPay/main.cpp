/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Purpose: Annual Pay 
 * Created on June 22, 2016, 9:24 PM
 */

#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    float payAmt=2200.0f;   // The amount of pay employees earns each pay period
    float payPer=26;        // The number of pay periods in a year 
    float annPay;        // Employee's total annual pay
    
    //Input Data
    
    //Process the Data
    annPay=payAmt*payPer;
    
    //Output the processed Data
    cout<<"The employee's total annual pay is "<<"$"<<annPay<<endl; 
    
    //Exit Stage Right!
     return 0;
}



