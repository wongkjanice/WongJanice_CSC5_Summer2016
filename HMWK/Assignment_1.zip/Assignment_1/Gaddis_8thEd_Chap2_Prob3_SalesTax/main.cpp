/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Purpose: Sales Tax
 * Created on June 22, 2016, 8:30 PM
 */

#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    float prchse=95;   //Total of purchase
    float stTax=0.04f; //State sales tax
    float counTax=0.02f;   //County sales tax 
    float tax;      //Total sales tax
   
    //Input Data
    
    //Process the Data
    tax=stTax*prchse+counTax*prchse;
   
    
    //Output the processed Data
    cout<<"The total sales tax on $95 is "<<"$"<<tax<<endl;
   
    
    //Exit Stage Right!
     return 0;
}



