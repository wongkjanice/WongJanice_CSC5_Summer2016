/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Purpose: Personal Information
 * Created on June 23, 2016, 11:21 PM
 */

#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    
    //Input Data
    
    
    //Process the Data
    
    
    //Output the processed Data
    cout<<"Janice Wong\n1803 Redfield Rd, Riverside CA 92507\n6263187470\nPublic Policy"<<endl;
    
    //Exit Stage Right!
     return 0;
}



