/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Purpose: Average of Values 
 * Created on June 22, 2016, 9:18 PM
 */

#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    int x1=28,x2=32,x3=37,x4=24,x5=33;//Values to average
    float avg;
   
    //Input Data
    
    //Process the Data
    avg =(x1+x2+x3+x4+x5)/5;
    
    //Output the processed Data
    cout<<"The average ="<<avg<<endl; 
    
    //Exit Stage Right!
     return 0;
}



