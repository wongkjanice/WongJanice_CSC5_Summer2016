/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Purpose: Restaurant Bill
 * Created on June 22, 2016, 8:55 PM
 */

#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    float meal=88.67; //Total meal charge
    float tax=0.0675; //Total meal tax 
    float tip=1.20;   //Total tip
    float totBil; //Total cost of meal with charge, tax, and tip
   
    //Input Data
    
    //Process the Data
    totBil=(meal*(1+tax))*tip;
    
    //Output the processed Data
    cout<<"The total meal cost is "<<"$"<<meal<<endl;
    cout<<"The total tax amount is "<<"$"<<(meal*(1+tax))-meal<<endl;
    cout<<"The total tip amount is "<<"$"<<totBil-(meal*(1+tax))<<endl;
    cout<<"The total bill is "<<"$"<<totBil<<endl;
    
    //Exit Stage Right!
     return 0;
}



