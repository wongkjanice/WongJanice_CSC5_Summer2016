/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Purpose: Coins - Monetary Value
 * Created on June 24, 2016, 1:15 PM
 */

#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    float q=25;   //value of a quarter
    float d=10;   //value of a dime
    float n=5;   //value of a nickel 
    float total;    //total amount of the coins 
    
    //Input Data
    
    
    //Process the Data
    total=2*q+3*d+n;
    
    //Output the processed Data
    cout<<"All together, the coins are worth "<<total<<" cents."<<endl;
    
    //Exit Stage Right!
     return 0;
}



