/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Purpose: Land Calculation
 * Created on June 23, 2016, 11:21 PM
 */

#include <iostream> //Input/Output Library
#include <iomanip>  //Formatting Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants
const float CNVFTAC=4.356e4f; //conversion from ft^2 to Acres
const float CNVMFT=1/5.28e3f; //Conversion from miles to ft
//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    float nAcres; //number of acres
    float nSqMls; //number of square miles 
    
    //Input Data
    cout<<"Enter the number of acres to convert to square miles"<<endl;
    cin>>nAcres;
    
    //Process the Data
    nSqMls=nAcres*CNVFTAC*CNVMFT*CNVMFT;
    
    //Output the processed Data
    cout<<nAcres<<"acres = "<<nSqMls<<"Miles^2"<<endl; 
    
    //Exit Stage Right!
     return 0;
}



