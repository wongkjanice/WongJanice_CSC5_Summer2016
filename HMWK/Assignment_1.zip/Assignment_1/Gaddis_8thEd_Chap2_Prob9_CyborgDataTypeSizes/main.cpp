/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Purpose: Cyborg Data Type Sizes
 * Created on June 23, 2016, 11:21 PM
 */

#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    char a;
    int b;
    float c;
    double d;   //This is gave you an F
    
    //Input Data
    
    //Process the Data
    
    //Output the processed Data
    cout<<"Character has          "<<sizeof(a)<<" bytes"<<endl;
    cout<<"Integer has            "<<sizeof(b)<<" bytes"<<endl;
    cout<<"Float has              "<<sizeof(c)<<" bytes"<<endl;
    cout<<"Double has             "<<sizeof(d)<<" bytes"<<endl;
    
    
    //Exit Stage Right!
     return 0;
}



