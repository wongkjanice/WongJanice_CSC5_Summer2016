/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Purpose: Ocean Levels 
 * Created on June 22, 2016, 9:37 PM
 */

#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    float ocnlvl=1.5f;   //Ocean levels rising at 1.5mm per year 
    float aftr5;       //The number of mm higher in 5 years 
    float aftr7;       //The number of mm higher in 7 years
    float aftr10;      //The number of mm higher in 10 years 
    //Input Data
    
    //Process the Data
            aftr5=ocnlvl*5; 
            aftr7=ocnlvl*7;
            aftr10=ocnlvl*10;        
            
    //Output the processed Data
    cout<<"In 5 years, the ocean's level will be "<<aftr5;
    cout<<"mm higher than the current level"<<endl; 
    cout<<"In 7 years, the ocean's level will be "<<aftr7;
    cout<<"mm higher than the current level"<<endl; 
    cout<<"In 10 years, the ocean's level will be "<<aftr10;
    cout<<"mm higher than the current level"<<endl; 
    
    //Exit Stage Right!
     return 0;
}



