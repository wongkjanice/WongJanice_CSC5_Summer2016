/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Purpose: Miles per gallon 
 * Created on June 23, 2016, 11:21 PM
 */

#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    float tMPG=23.5;    //Average miles per gallon when driven in town
    float hMPG=28.9;    //Average miles per gallon when driven on highway
    unsigned char nGal=20;      //20 gallon gas tank
    float dT;           //Distance in town
    float dH;           //Distance on highway
    
    //Input Data
    
    //Process the Data
    dT=tMPG*nGal;
    dH=hMPG*nGal;
    
    //Output the processed Data
    cout<<"When driven in town, the car can drive and average of "<<dT;
    cout<<" miles per Tank of Gas"<<endl;
    cout<<"When driven on the highway, the car can drive an average of "<<dH;
    cout<<" miles per Tank of Gas"<<endl;
    
    //Exit Stage Right!
     return 0;
}



