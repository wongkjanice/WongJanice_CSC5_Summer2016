/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Purpose: Miles per gallon 
 * Created on June 23, 2016, 11:21 PM
 */

#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    float nGal=15;      //The number of Gallons
    float miDrv=375;    //Total number of miles before refueling
    float mph;          //miles per hour
    
    
    //Input Data
    
    //Process the Data
    mph=miDrv/nGal;
    
    //Output the processed Data
    cout<<"The number of miles per gallon the car gets is "<<mph<<"mph"<<endl;
    
    //Exit Stage Right!
     return 0;
}



