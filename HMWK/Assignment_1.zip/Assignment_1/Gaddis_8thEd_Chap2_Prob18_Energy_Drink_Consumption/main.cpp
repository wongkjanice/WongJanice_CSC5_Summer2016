/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Purpose: Energy Drink Consumption 
 * Created on June 24, 2016, 11:36 AM
 */

#include <iostream> //Input/Output Library
#include <iomanip>  //Formatting Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    short srvCstm=16500; //number of surveyed customer
    float more=0.15f; //those who purchase 1 or more drinks/week
    float citrus=0.58f; //those who prefer citrus-flavored energy drinks
    float nMore,pCitrus;//total customer who purchases one or more drinks, total customers that prefer citrus flavored drinks 
    
    //Input Data
    
    
    //Process the Data
    nMore=srvCstm*more;
    pCitrus=srvCstm*citrus;
           
    
    //Output the processed Data
    cout<<setprecision(4)<<showpoint;
    cout<<"The approximate number of customers in the survery "<<
            "who purchase one or more energy drinks per week is "<<nMore<<endl;
    cout<<"The approximate number of customers in the survery "<<
            "who prefer citrus-flavored energy drinks is "<<pCitrus<<endl;
    
    //Exit Stage Right!
     return 0;
}



