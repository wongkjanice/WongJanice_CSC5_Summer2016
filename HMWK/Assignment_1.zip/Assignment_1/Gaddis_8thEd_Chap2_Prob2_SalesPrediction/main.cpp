/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Purpose: Sales Prediction
 * Created on June 22, 2016, 8:17 PM
 */

#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    float east=0.58; //total sales percentage for east coast
    float totsal=8.6e6f; //total sales 
   
    //Input Data
    
    //Process the Data
    east=east*totsal;
    
    //Output the processed Data
    cout<<"The East Coast Division will generate $ "<<east<<endl;
    
    //Exit Stage Right!
     return 0;
}



