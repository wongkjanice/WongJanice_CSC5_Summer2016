/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Purpose: Object in Freefall
 * Created on June 24, 2016, 1:21 PM
 */

#include <iostream> //Input/Output Library
#include <cmath>
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    float d;    //Distance of freefall
    float t;    //Time in seconds it takes for object to fall
    int a=32;   //feet per second
    
    //Input Data
    cout<<"Enter a time in seconds."<<endl;
    cin>>t;
    
    //Process the Data
    d= (a*t*t)/2;
    
    //Output the processed Data
    
    cout<<"An object in freefall for "<<t<<" seconds will fall "<<d<<"ft"<<endl;
    
    //Exit Stage Right!
     return 0;
}



