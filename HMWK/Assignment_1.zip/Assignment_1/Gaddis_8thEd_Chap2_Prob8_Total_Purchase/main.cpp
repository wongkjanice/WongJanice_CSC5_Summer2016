/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Purpose: Total Purchase
 * Created on June 23, 2016, 9:37 PM
 */

#include <iostream> //Input/Output Library
#include <iomanip>  //Formatting Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    float a=15.95;      //Price of item 1
    float b=24.95;      //Price of item 2
    float c=6.95;       //Price of item 3
    float d=12.95;      //Price of item 4
    float e=3.95;       //Price of item 5
    float sbTot;        //Subtotal of sale
    float sTax=1.07;    //Sales tax
    float amtST;        //The amount of sales tax
    float total;        //The total 
    
    //Input Data
    
    //Process the Data
    sbTot=a+b+c+d+e;
    amtST=(sbTot*1.07)-sbTot;
    total=sbTot*1.07;
            
    //Output the processed Data
    cout<<"The price of item 1 is "<<"$"<<a<<endl;
    cout<<"The price of item 2 is "<<"$"<<b<<endl;
    cout<<"The price of item 3 is "<<"$"<<c<<endl;
    cout<<"The price of item 4 is "<<"$"<<d<<endl;
    cout<<"The price of item 5 is "<<"$"<<e<<endl;
    cout<<"The subtotal of sale is "<<"$"<<sbTot<<endl;
    cout<<setprecision(3)<<showpoint;
    cout<<"The amount of sales tax is "<<"$"<<amtST<<endl;
    cout<<"The total of the purchase is "<<"$"<<total<<endl;
    
    
    //Exit Stage Right!
     return 0;
}



