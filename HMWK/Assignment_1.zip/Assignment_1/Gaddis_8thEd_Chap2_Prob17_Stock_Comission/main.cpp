/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: JaniceWong
 * Purpose: Stock Comission
 * Created on June 24, 2016, 11:21 AM
 */

#include <iostream> //Input/Output Library
#include <iomanip>  //Formatting Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    unsigned short nShare=750; //values of the stock $’s 
    unsigned char stkPrce=35; //commission paid in $’s
    float commish=1.02f; // 2 percent commission
    float valstk,cpaid,totpaid;
    
    //Input Data
    
    
    //Process the Data
    valstk=nShare*stkPrce;
    cpaid=(valstk*commish)-valstk;
    totpaid=valstk*commish;
    
    
    //Output the processed Data
    cout<<setprecision(7)<<showpoint;
    cout<<"Price paid for stock $ "<<valstk<<endl;
    cout<<"Commission paid = $ "<<cpaid<<endl;
    cout<<"Total of transaction = $ "<<totpaid<<endl;
    
    //Exit Stage Right!
     return 0;
}



