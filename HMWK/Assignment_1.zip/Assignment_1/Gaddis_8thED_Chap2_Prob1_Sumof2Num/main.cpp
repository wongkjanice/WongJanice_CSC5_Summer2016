/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Janice Wong
 * Created on June 22, 2016, 7:47 PM
 * Purpose: Sum of Two Numbers 
 */

#include <iostream> //Input/Output Library
using namespace std; //Namespace of the System Libraries

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {
    //Declare Variables
    int a=50;
    int b=100;
    int total; 
    //Input Data
    
    //Process the Data
    total=a+b;
        
    //Output the processed Data
    cout<<"Total of 50 + 100 is "<<total<<endl;
            
    //Exit Stage Right!
     return 0;
}

